const express = require('express');
const router = express.Router();
const upload = require('../middlewares/upload');

const {
    getStudents,
    addStudent,
    updateStudent,
    deleteStudent,
    uploadCSV
} = require('../controllers/studentController');

router.get('/', getStudents);
router.post('/', addStudent);
router.put('/:id', updateStudent);
router.delete('/:id', deleteStudent);
router.post('/upload', upload.single('file'), uploadCSV);

module.exports = router;
