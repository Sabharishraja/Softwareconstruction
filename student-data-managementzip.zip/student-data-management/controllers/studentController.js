const sql = require('mssql');
const config = require('../db');
const csv = require('csv-parser');
const stream = require('stream');

// GET all students
const getStudents = async (req, res) => {
    try {
        const pool = await sql.connect(config);
        const result = await pool.request().query('SELECT * FROM Students');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
};

// ADD a new student
const addStudent = async (req, res) => {
    const { name, grade, course } = req.body;
    try {
        const pool = await sql.connect(config);
        await pool.request()
            .input('name', sql.VarChar, name)
            .input('grade', sql.VarChar, grade)
            .input('course', sql.VarChar, course)
            .query('INSERT INTO Students (name, grade, course) VALUES (@name, @grade, @course)');
        res.send('Student added successfully');
    } catch (err) {
        res.status(500).send(err.message);
    }
};

// UPDATE student
const updateStudent = async (req, res) => {
    const { id } = req.params;
    const { name, grade, course } = req.body;
    try {
        const pool = await sql.connect(config);
        await pool.request()
            .input('id', sql.Int, id)
            .input('name', sql.VarChar, name)
            .input('grade', sql.VarChar, grade)
            .input('course', sql.VarChar, course)
            .query('UPDATE Students SET name = @name, grade = @grade, course = @course WHERE id = @id');
        res.send('Student updated');
    } catch (err) {
        res.status(500).send(err.message);
    }
};

// DELETE student
const deleteStudent = async (req, res) => {
    const { id } = req.params;
    try {
        const pool = await sql.connect(config);
        await pool.request()
            .input('id', sql.Int, id)
            .query('DELETE FROM Students WHERE id = @id');
        res.send('Student deleted');
    } catch (err) {
        res.status(500).send(err.message);
    }
};

// UPLOAD CSV
const uploadCSV = async (req, res) => {
    if (!req.file) return res.status(400).send('No file uploaded.');

    const results = [];
    const bufferStream = new stream.PassThrough();
    bufferStream.end(req.file.buffer);

    bufferStream
        .pipe(csv())
        .on('data', (row) => {
            if (row.name && row.grade && row.course) {
                results.push(row);
            }
        })
        .on('end', async () => {
            try {
                const pool = await sql.connect(config);
                for (const student of results) {
                    await pool.request()
                        .input('name', sql.VarChar, student.name)
                        .input('grade', sql.VarChar, student.grade)
                        .input('course', sql.VarChar, student.course)
                        .query('INSERT INTO Students (name, grade, course) VALUES (@name, @grade, @course)');
                }
                res.send(`${results.length} students uploaded successfully.`);
            } catch (err) {
                res.status(500).send(err.message);
            }
        });
};

module.exports = {
    getStudents,
    addStudent,
    updateStudent,
    deleteStudent,
    uploadCSV
};
